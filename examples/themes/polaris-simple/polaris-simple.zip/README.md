﻿# Polaris Simple

## 中文

这个示例包包含监控页和机器页两个子主题，使用公开只读主题 SDK 读取真实数据。默认跟随页面的浅色、深色或系统配色设置。主题配置支持“强调色”和可选的“标题”；标题为空时使用站点标题。

1. 在管理后台的主题管理中上传 `polaris-simple-0.1.0.zip`。
2. 分别预览监控页和机器页；机器页入口需要先开启独立机器展示。
3. 应用所需的子主题，再在对应的主题配置中修改选项。安装本身不会切换当前主题。

Worker 需要配置 `THEMES` R2 绑定；Go 需要可写且持久化的数据目录。此示例未运行测试，请在自己的环境中验证。

## English

This package contains monitor and machine themes. Both read real public data through the read-only theme SDK. The color mode follows the page setting. Each theme offers an accent color and an optional headline; an empty headline uses the site title.

1. Upload `polaris-simple-0.1.0.zip` in theme management.
2. Preview the monitor and machine themes. Enable the separate machine page to use the machine theme.
3. Apply the desired theme and adjust its options in the corresponding page panel. Uploading alone does not activate it.

Worker requires a `THEMES` R2 binding; Go requires a writable, persistent data directory. This example has not been tested; verify it in your own environment.
